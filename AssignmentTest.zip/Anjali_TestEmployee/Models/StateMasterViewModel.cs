﻿using System.ComponentModel.DataAnnotations;

namespace Anjali_TestEmployee.Models
{
    [MetadataType(typeof(StateMasterMetadata))]
    public partial class StateMaster
    {
    }

    public class StateMasterMetadata
    {
        public int StateId { get; set; }

        [Display(Name = "State Name")]
        public string StateName { get; set; }
    }
}