﻿using Anjali_TestEmployee.Utility;
using System.ComponentModel.DataAnnotations;

namespace Anjali_TestEmployee.Models
{
    [MetadataType(typeof(EmployeeMetadata))]
    public partial class Employee
    {
        [Display(Name = "District Name")]
        public string DistrictName { get; set; }

        [Display(Name = "State Name")]
        public string StateName { get; set; }
    }

    public class EmployeeMetadata
    {
        [Required]
        [StringLength(200, MinimumLength = 3)]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Date Of Birth")]
        [DateOfBirthValidation(18)]
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        public System.DateTime DateOfBirth { get; set; }

        [Required]
        [MaxLength(500)]
        public string Address { get; set; }

        [Required]
        public int DistrictId { get; set; }

        [Required]
        // must be non negative
        public decimal Salary { get; set; }
    }
}