﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Anjali_TestEmployee.Models
{
    [MetadataType(typeof(DistrictMasterMetadata))]
    public partial class DistrictMaster
    {
    }

    public class DistrictMasterMetadata
    {
        public int DistrictId { get; set; }

        [Display(Name = "District Name")]
        public string DistrictName { get; set; }

        public Nullable<int> StateId { get; set; }
    }
}