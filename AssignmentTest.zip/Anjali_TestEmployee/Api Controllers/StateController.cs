﻿using Anjali_TestEmployee.Models;
using System.Linq;
using System.Web.Http;

namespace Anjali_TestEmployee.Controllers
{
    public class StateController : ApiController
    {
        EmployeeDbContext _db = new EmployeeDbContext();

        public IHttpActionResult Get()
        {
            var states = _db.StateMasters.ToList();
            return Ok(states);
        }
    }
}
