﻿using Anjali_TestEmployee.Models;
using System.Linq;
using System.Web.Http;

namespace Anjali_TestEmployee.Controllers
{
    public class DistrictController : ApiController
    {
        EmployeeDbContext _db = new EmployeeDbContext();

        [HttpGet]
        public IHttpActionResult Get()
        {
            var districts = _db.DistrictMasters.ToList();
            return Ok(districts);
        }
    }
}
