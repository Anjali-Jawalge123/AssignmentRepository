﻿using Anjali_TestEmployee.Api_Client;
using Anjali_TestEmployee.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Mvc;

namespace Anjali_TestEmployee.Controllers
{
    public class HomeController : Controller
    {
        ApiHttpClient _client;
        EmployeeDbContext _db;

        public HomeController()
        {
            _client = new ApiHttpClient();
            _db = new EmployeeDbContext();
        }

        [HttpGet]
        public ViewResult Index()
        {
            var employees = _client.GetEmployees();
            if (employees == null)
            {
                employees = Enumerable.Empty<Employee>();

                ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
            }
            return View(employees);
        }

        [HttpGet]
        [ChildActionOnly]
        public PartialViewResult Create()
        {
            LoadStates();

            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                if(employee.DistrictId == 0)
                {
                    ModelState.AddModelError("DistrictId", "Please select district");
                    return View();
                }

                _db.Employees.Add(employee);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }

            LoadStates();

            return View();
        }

        void LoadStates()
        {
            var states = _db.StateMasters.Select(s => new SelectListItem()
            {
                Text = s.StateName,
                Value = s.StateId.ToString()
            }).ToList();

            ViewBag.StateId = states;

            states.Insert(0,
                new SelectListItem() { Text = "-- Select State --", Value = "-1" });

            var districts = new List<SelectListItem>()
            {
                new SelectListItem() { Text = "-- Select District --", Value = "-1" }
            };
            ViewBag.DistrictId = districts;
        }

        [HttpGet]
        public JsonResult LoadDistricts(int? StateId)
        {
            var districts = new List<SelectListItem>()
            {
                new SelectListItem() { Text = "-- Select District --", Value = "-1" }
            };

            if (StateId != null && StateId > 0)
            {
                EmployeeDbContext _db = new EmployeeDbContext();

                districts = _db.DistrictMasters.
                    Where(dm => dm.StateId == StateId).
                    Select(d => new SelectListItem()
                    {
                        Text = d.DistrictName,
                        Value = d.DistrictId.ToString()
                    }).ToList();
                districts.Insert(0,
                    new SelectListItem() { Text = "-- Select District --", Value = "-1" });
            }

            return Json(districts, JsonRequestBehavior.AllowGet);
        }
    }
}
