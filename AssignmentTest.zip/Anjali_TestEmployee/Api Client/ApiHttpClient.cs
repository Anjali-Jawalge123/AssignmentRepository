﻿using Anjali_TestEmployee.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace Anjali_TestEmployee.Api_Client
{
    public class ApiHttpClient
    {
        public IEnumerable<Employee> GetEmployees()
        {
            IEnumerable<Employee> employees = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59851/api/");
                var responseTask = client.GetAsync("employee");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait();

                    employees = readTask.Result;
                }                
            }

            return employees;
        }

        public IEnumerable<StateMaster> GetStates()
        {
            IEnumerable<StateMaster> states = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59851/api/");
                var responseTask = client.GetAsync("state");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<StateMaster>>();
                    readTask.Wait();

                    states = readTask.Result;
                }
            }

            return states;
        }

        public IEnumerable<DistrictMaster> GetDistricts()
        {
            IEnumerable<DistrictMaster> districts = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59851/api/");
                var responseTask = client.GetAsync("district");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<DistrictMaster>>();
                    readTask.Wait();

                    districts = readTask.Result;
                }
            }

            return districts;
        }
    }
}