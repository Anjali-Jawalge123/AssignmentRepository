﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Anjali_TestEmployee.Utility
{
    public class DateOfBirthValidation : ValidationAttribute
    {
        private int _Limit;
        public DateOfBirthValidation(int Limit)
        {
            this._Limit = Limit;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime bday = DateTime.Parse(value.ToString());
                DateTime today = DateTime.Today;
                int age = today.Year - bday.Year;
                if (bday > today.AddYears(-age))
                {
                    age--;
                }
                if (age < _Limit)
                {
                    var result = new ValidationResult("Sorry, age should be greater than 18 years");
                    return result;
                }
            }
            return null;
        }
    }
}